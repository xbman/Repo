import util, urllib2 , os , xbmcaddon , urllib , xbmcgui , xbmcplugin , sqlite3
import requests , json
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

mysettings = xbmcaddon.Addon(id = 'plugin.video.FloSports')
getSetting = xbmcaddon.Addon().getSetting

profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
logos = xbmc.translatePath(os.path.join(home, 'resources\logos\\')) # subfolder for logos
nexticon = xbmc.translatePath(os.path.join(home, 'next.png'))
refreshicon = xbmc.translatePath(os.path.join(home, 'clear.png'))
homemenu = xbmc.translatePath(os.path.join(home, 'resources', 'playlists'))

enable_settings = mysettings.getSetting('enable_settings')
enable_custom_view = mysettings.getSetting('enable_custom_view')
menu_view = mysettings.getSetting('menu_view')
thumb_view = mysettings.getSetting('thumb_view')
#xbmc.executebuiltin("Container.SetViewMode(50)")

ipp = int(mysettings.getSetting('lang_type'))
if ipp == 0:
    MaxResults = '25'
elif ipp == 1:
    MaxResults = '50'
elif ipp == 2:
    MaxResults = '100'
elif ipp == 3:
    MaxResults = '150'

ClearImages = 'ClearImages'
NextPage = 'NextPage'
varsity = 'varsity'
gymnastics = 'gymnastics'
wrestling = 'wrestling'
flotrack = 'flotrack'
milesplit = 'milesplit'
elite = 'elite'
softball = 'softball'
hoops = 'hoops'
cheer = 'cheer'
combat = 'combat'
grappling = 'grappling'
volleyball = 'volleyball'
tennis = 'tennis'
floko = 'floko'
climbing = 'climbing'
marching = 'marching'
swimming = 'swimming'
hockey = 'hockey'
rodeo = 'rodeo'
floslam = 'floslam'
racing = 'racing'
voice = 'voice'
rugby = 'rugby'
dance = 'dance'
cats = 'cats'
flolive = 'flolive'
Tagsz = 'Tagsz'
Categories = 'Categories'
Settings = 'Settings'
#xbmcplugin.setContent(int(sys.argv[1]), 'movies')


def searchUser(url,mode,top,pn,tag,v):
    try:
        keyb = xbmc.Keyboard('', '[COLOR yellow]Enter search text[/COLOR]')
        keyb.doModal()
        if (keyb.isConfirmed()):
            searchText = urllib.quote_plus(keyb.getText())
            user = str(searchText)
        TheUrl = younowuser + user
        tag = 'None'
        #buildMenu(TheUrl,url,mode,top,pn,tag,v)
        add_dir(TheUrl, PageOne, 0, 1, 'None', 2, icon, fanart)
    except:
        pass

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if mysettings.getSetting('enable_custom_view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % mysettings.getSetting(viewType) )

    # set sort methods - probably we don't need all of them
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    #xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )

def make_unicode(input):
    if type(input) != unicode:
        input =  input.decode('utf-8')
        return input
    else:
        return input

def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param


def playVideo(params):
        videoLink = params['video']
        url = params['Page']
        mode = params['Type']
        pn = params['pn']
        util.playMedia(params['title'], params['image'], videoLink, 'Video')

def add_dir(name, url, top, pn, tag, v, mode, iconimage, fanart):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&top=" + str(top) + "&pn=" + str(pn) + "&tag=" + str(tag) + "&v=" + str(v) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
    fanart = fanart
    liz.setArt({'fanart': fanart})
    liz.setInfo(type="Video", infoLabels={ "Title": name, "plot": name })
    ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
    return ok

def add_dir2(name, url, mode, iconimage, fanart):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
    fanart = fanart
    liz.setArt({'fanart': fanart})
    liz.setInfo(type="Video", infoLabels={ "Title": name, "plot": name })
    ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = False)
    return ok

def main():
   # if getSetting("enable_clear_images") == 'true':
   #     add_dir2('[COLOR indianred]Clear LiveMe Images[/COLOR]', ClearImages, 2, refreshicon, fanart)

    #if getSetting("enable_liveme_broadcasters") == 'true':
    add_dir('[COLOR orange][B]Var[/B][/COLOR][B]sityTV[/B]', varsity, 20, 1, 'None', 0, 2, logos + 'varsity.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Live[/B]', flolive, 35, 1, 'None', 0, 2, logos + 'live.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Gymnastics[/B]', gymnastics, 4, 1, 'None', 0, 2, logos + 'gymnastics.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Wrestling[/B]', wrestling, 2, 1, 'None', 0, 2, logos + 'wrestling.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Track[/B]', flotrack, 1, 1, 'None', 0, 2, logos + 'track.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Elite[/B]', elite, 12, 1, 'None', 0, 2, logos + 'elite.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Softball[/B]', softball, 14, 1, 'None', 0, 2, logos + 'softball.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Hoops[/B]', hoops, 7, 1, 'None', 0, 2, logos + 'hoops.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Cheer[/B]', cheer, 10, 1, 'None', 0, 2, logos + 'cheer.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Combat[/B]', combat, 23, 1, 'None', 0, 2, logos + 'combat.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Grappling[/B]', grappling, 8, 1, 'None', 0, 2, logos + 'grappling.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Volleyball[/B]', volleyball, 22, 1, 'None', 0, 2, logos + 'volleyball.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Tennis[/B]', tennis, 25, 1, 'None', 0, 2, logos + 'tennis.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]KO[/B]', floko, 24, 1, 'None', 0, 2, logos + 'KO.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Climbing[/B]', climbing, 26, 1, 'None', 0, 2, logos + 'climbing.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Marching[/B]', marching, 27, 1, 'None', 0, 2, logos + 'marching.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Swimming[/B]', swimming, 28, 1, 'None', 0, 2, logos + 'swimming.png', fanart)
   # add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Hockey[/B]', hockey, 29, 1, 'None', 0, 2, logos + 'hockey.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Rodeo[/B]', rodeo, 30, 1, 'None', 0, 2, logos + 'rodeo.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Slam[/B]', floslam, 31, 1, 'None', 0, 2, logos + 'slam.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Racing[/B]', racing, 32, 1, 'None', 0, 2, logos + 'racing.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Voice[/B]', voice, 33, 1, 'None', 0, 2, logos + 'voice.png', fanart)
    add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Rugby[/B]', rugby, 34, 1, 'None', 0, 2, logos + 'rugby.png', fanart)
   # add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Dance[/B]', dance, 36, 1, 'None', 0, 2, logos + 'dance.png', fanart)
   # add_dir('[COLOR orange][B]Flo[/B][/COLOR][B]Cats[/B]', cats, 9, 1, 'None', 0, 2, icon, fanart)
   # add_dir('[B]MileSplit[/B]', milesplit, 15, 1, 'None', 0, 2, milesplit, fanart)

    #if getSetting("enable_trending_tags") == 'true':
    #    add_dir('[COLOR seagreen][B]Trending[B][/COLOR] [COLOR yellowgreen][B] Tags[/B][/COLOR]', Categories, 0, 1, 'None', 0, 2, icon, fanart)
    if getSetting("enable_settings") == 'true':
        add_dir2('[COLOR slategray]Settings[/COLOR]', Settings, 3, icon, fanart)
    setView('movies', 'menu_view')

def start(url,mode,top,pn,tag,v):
    if 'varsity' in url:
        if mysettings.getSetting("auto_clear") == "true":
            clean_database(False)
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=20'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'flolive' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=35'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'gymnastics' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=4'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'wrestling' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=2'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'flotrack' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=1'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'milesplit' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=15'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'elite' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=12'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'softball' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=14'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'hoops' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=7'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'cheer' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=10'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'combat' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=23'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'grappling' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=8'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'volleyball' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=22'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'tennis' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=25'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'floko' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=24'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'climbing' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=26'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'marching' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=27'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'swimming' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=28'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'hockey' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=29'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'rodeo' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=30'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'slam' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=31'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'racing' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=32'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'voice' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=33'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'rugby' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=34'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'dance' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=36'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'cats' in url:
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=1&limit=' + MaxResults + '&siteId=9'
        buildMenu(TheUrl,url,mode,top,pn,tag,v)

    elif 'NextPage' in url:
        params = get_params()
        pn = params['pn']
        top = params['top']
        TheUrl = 'https://api.flocasts.com/videos?status=published&order=publish_date&direction=desc&page=' + pn + '&limit=' + MaxResults + '&siteId=' + top
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'Categories' in url:
        if mysettings.getSetting("auto_clear") == "true":
            clean_database(False)
        params = get_params()
        v = params['v']
        TheUrl = youtags
        getTags(TheUrl)
    elif 'Tagsz' in url:
        params = get_params()
        tag = params['tag']
        top = params['top']
        pn = params['pn']
        v = params['v']
        TheUrl = younowtags + top + '/' + 'tag=' + tag
        buildMenu(TheUrl,url,mode,top,pn,tag,v)
    elif 'ClearImages' in url:
        clean_database(showdialog=True)

def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".cmcm.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".cmcm.com")
            if showdialog:
                util.notifyClear('Finished','LiveMe images cleared.')
    except:
        pass

def getTags(TheUrl):
    response = urllib2.urlopen(TheUrl)
    params = get_params()
    totalusers = 0
    if response and response.getcode() == 200:
        content = response.read()
        gets = util.extractAll(content, 'tag', 'isEp')
        for getit in gets:
            totalusers = totalusers + 1
            params['tag'] = util.extract(getit, '":"', '","viewers"')
            params['viewers'] = util.extract(getit, '"viewers":', ',"live"')
            params['live'] = util.extract(getit, '"live":', ',"')
            tag = params['tag']
            viewers = params['viewers']
            live = params['live']
            add_dir('Trending Tags #[COLOR greenyellow][B]' + str(tag) + '[/B][/COLOR]' + ' Live:(' + str(live) + ')', Tagsz, 0, 1, tag, 0, 2, icon, fanart)
        #util.endListing()
    else:
        util.showError(ADDON_ID, 'Could not open URL %s to create menu' % (url))
    setView('movies', 'menu_view')


def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11')
		#req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36')
		response = urllib2.urlopen(req, timeout = 60)
		link = response.read()
		response.close()
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code
		elif hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason

def buildMenu(TheUrl,url,mode,top,pn,tag,v):
    params = get_params()
    totalusers = 0
    pn = params['pn']
    #video = params['video']
    top = params['top']
    r = requests.get(TheUrl)
    r.text
    data = json.loads(r.text)

    for item in data["_embedded"]["items"]:
        totalusers = totalusers + 1
        params = {'play':1}
        params['title'] = item['shortTitle']
        TESTSHIT = item['embedCode']
        params['MSG'] = item['title']

        video1 = 'http://player.ooyala.com/player/all/' + TESTSHIT + '_4000.m3u8'
        video2 = 'http://player.ooyala.com/player/all/' + TESTSHIT + '_1500.m3u8'

        params['isPr'] = item['isPremium']
        params['image'] = item['thumbnail']
        params['pub'] = item['publishDate']
        params['rtime'] = item['duration']

        TEST1 = params['image']
        TEST1 = TEST1.replace("http://flocasts-thumb.scaleengine.net", "")
        TEST1 = TEST1.replace("_small.jpg", "")
        TEST1 = TEST1.replace("_large.jpg", "")
        video3 = 'http://flocasts-vod.videocdn.scaleengine.net/flocasts-vod/play/smil:sestore3/flocasts/recordings/' + TEST1 + '.smil/playlist.m3u8'
        video4 = 'http://flocasts-vod.videocdn.scaleengine.net/flocasts-vod/play/smil:sestore2/flocasts/recordings/' + TEST1 + '.mp4/playlist.m3u8'
        video5 = 'http://flocasts-vod.videocdn.scaleengine.net/flocasts-vod/play/smil:sestore3/flocasts/recordings/' + TEST1 + '.smil/playlist.m3u8'
        #video5 = 'http://player.ooyala.com/player.swf?embedCode=' + TEST1 + '&version=2'
        #video5 = 'http://player.ooyala.com/player.swf?embedCode=' + TEST1 + '&version=2'
        AV = video1
        TEST2 = params['image']
        if 'flocasts-thumb.scaleengine.net' in TEST2:
            AV = video3
        #if 'cf.c.ooyala.com' in TEST2:
        #    AV = video2
        else:
            AV = video1


        GetThumb = item['thumbnail']
        if GetThumb.find("http:") == -1:
            params['image'] = 'http:' + item['thumbnail']
        else:
            params['image'] = item['thumbnail']

        params['Page'] = url
        params['Type'] = mode
        params['top'] = top
        params['pn'] = pn
        params['tag'] = tag

        if params['isPr'] == True:
            if top == '20':
                params['video'] = video2
                link = util.makeLink(params)
            elif top == '1':
                params['video'] = AV
                link = util.makeLink(params)
            elif top == '2':
                params['video'] = video5
                link = util.makeLink(params)
            elif top == '12':
                params['video'] = video4
                link = util.makeLink(params)
            elif top == '26':
                params['video'] = video1
                link = util.makeLink(params)
            else:
                params['video'] = video1
            link = util.makeLink(params)
            util.addMenuItem2('[COLOR=mediumseagreen]' + params['title'] + '[/COLOR]', params['MSG'], params['pub'], params['rtime'], link, icon, params['image'], False)
        else:
            params['video'] = video1
            link = util.makeLink(params)
            util.addMenuItem2('[COLOR=limegreen]' +params['title']+ '[/COLOR]', params['MSG'], params['pub'], params['rtime'], link, icon, params['image'], False)


       # params['Page'] = url
       # params['Type'] = mode
       # params['top'] = top
       # params['pn'] = pn
       # params['tag'] = tag



    if totalusers > 24 and tag == 'None':
        pn = int(pn) + 1
        wp = int(pn) - 1
        add_dir('[COLOR slategray]P' + str(wp) + '[/COLOR] [COLOR=orange][B]Next Page[/B][/COLOR][COLOR tomato][B]>>[/B][/COLOR][COLOR lightsalmon][B]' + str(pn) + '[/B][/COLOR]', NextPage, top, pn, tag, v, 2, nexticon, fanart)
    if totalusers == 0:
        add_dir('[COLOR=darkkhaki]No Results:[/COLOR] ' + str(tag), Categories, 0, 1, tag, 0, 2, icon, fanart)
    setView('movies', 'thumb_view')

def settings():
    xbmcaddon.Addon().openSettings()

def test():
    params = get_params()
    url = None
    name = None
    mode = None
    iconimage = None
    top = '0'
    pn = '1'
    v = '0'
    tag = 'None'
    image = icon
    try:
        url = urllib.unquote_plus(params["url"])
    except:
        pass
    try:
        url = urllib.unquote_plus(params["image"])
    except:
        pass
    try:
        name = urllib.unquote_plus(params["name"])
    except:
        pass
    try:
        top = str(params["top"])
    except:
        pass
    try:
        pn = str(params["pn"])
    except:
        pass
    try:
        tag = str(params["tag"])
    except:
        pass
    try:
        v = str(params["v"])
    except:
        pass
    try:
        mode = int(params["mode"])
    except:
        pass
    try:
        iconimage = urllib.unquote_plus(params["iconimage"])
    except:
        pass
    if mode == None or url == None or len(url) < 1:
        main()
    elif mode == 1:
        searchUser(url,mode,top,pn,tag,v)
    elif mode == 2:
        start(url,mode,top,pn,tag,v)
    elif mode == 3:
        settings()
    elif mode == 4:
        searchTags(url,mode,top,pn,tag,v)



parameters = util.parseParameters()
if 'play' in parameters:
    params = get_params()
    mode = params['Type']
    url = params['Page']
    #totalusers = params['Num']
    #url = None
    #mode = None
    try:
	    url = urllib.unquote_plus(params["url"])
    except:
	    pass
    try:
	    mode = int(params["mode"])
    except:
	    pass
    playVideo(parameters)
else:
    test()



xbmcplugin.endOfDirectory(int(sys.argv[1]))