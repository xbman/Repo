import util, urllib2, os, xbmcaddon, urllib, xbmcgui, xbmcplugin, sqlite3

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
mysettings = xbmcaddon.Addon(id = 'plugin.video.ChaturCam')
getSetting = xbmcaddon.Addon().getSetting

cb_playmode = int(mysettings.getSetting('cb_play_mode'))
backmode = int(mysettings.getSetting('back_type'))
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
logos = xbmc.translatePath(os.path.join(home, 'icon.png')) # subfolder for logos
homemenu = xbmc.translatePath(os.path.join(home, 'resources', 'playlists'))

ClearImages = 'ClearImages'
NextPage = 'NextPage'
PageOne = 'PageOne'

Chaturbate1 = 'Chaturbate1'
cb1 = 'cb1'


Settings = 'Settings'

profileDir = mysettings.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
favoritesdb = os.path.join(profileDir, 'favorites.db')

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if mysettings.getSetting('enable_custom_view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % mysettings.getSetting(viewType) )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def main():

    util.add_dir('[COLOR deeppink][B]Chaturbate[/B][/COLOR]', Chaturbate1, 0, 0, 2, icon, fanart)

#    if getSetting("enable_favorites") == 'true':
#        util.add_dir('[COLOR cadetblue][B]Favorites[/B][/COLOR]', Favorites, 0, 0, 2, icon, fanart)

    if getSetting("enable_settings") == 'true':
        util.add_dir3('[COLOR slategray]Settings[/COLOR]', Settings, 0, 0, None, 0, 3, icon, fanart)

    setView('movies', 'menu_view')


def start(url,pn,mode,channelname,iconimage):
    female = True if addon.getSetting("enable_female") == "true" else False
    male = True if addon.getSetting("enable_male") == "true" else False
    couple = True if addon.getSetting("enable_couples") == "true" else False
    trans = True if addon.getSetting("enable_trans") == "true" else False
    clearchaturbate = True if addon.getSetting("enable_clear_chaturbate") == "true" else False

    if 'Chaturbate1' in url:
        if clearchaturbate: util.add_dir('[COLOR slategreay]Clear Chaturbate Images[/COLOR]', ClearImages, 0, 0, 2, icon, fanart)

        ### MAIN URLS.
        util.add_dir('[COLOR deeppink][B]Featured[/B][/COLOR]', 'https://chaturbate.com/?page=1',pn, channelname, 55, icon, fanart)
        if female: util.add_dir('[COLOR hotpink][B]Female[/B][/COLOR]', 'https://chaturbate.com/female-cams/?page=1',pn, channelname, 55, icon, fanart)
        if couple: util.add_dir('[COLOR palevioletred][B]Couples[/B][/COLOR]', 'https://chaturbate.com/couple-cams/?page=1',pn, channelname, 55, icon, fanart)
        if trans: util.add_dir('[COLOR mediumvioletred][B]Trans[/B][/COLOR]', 'https://chaturbate.com/trans-cams/?page=1',pn,channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]Male[/B][/COLOR]', 'https://chaturbate.com/male-cams/?page=1',pn, channelname, 55, icon, fanart)
        ### NEW-CAMS
        if female: util.add_dir('[COLOR hotpink][B]New Females[/B][/COLOR]', 'https://chaturbate.com/new-cams/female/?page=1',pn, channelname, 55, icon, fanart)
        if couple: util.add_dir('[COLOR palevioletred][B]New Couples[/B][/COLOR]', 'https://chaturbate.com/new-cams/couple/?page=1',pn, channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]New Males[/B][/COLOR]', 'https://chaturbate.com/new-cams/male/?page=1',pn, channelname, 55, icon, fanart)
        ### AGE
        if female: util.add_dir('[COLOR hotpink][B]Female 18+[/B][/COLOR]', 'https://chaturbate.com/teen-cams/female/?page=1',pn, channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]Male 18+[/B][/COLOR]', 'https://chaturbate.com/teen-cams/male/?page=1',pn, channelname, 55, icon, fanart)
        if female: util.add_dir('[COLOR hotpink][B]18-21 Female[/B][/COLOR]', 'https://chaturbate.com/18to21-cams/female/?page=1',pn, channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]18-21 Male[/B][/COLOR]', 'https://chaturbate.com/18to21-cams/male/?page=1',pn, channelname, 55, icon, fanart)
        if female: util.add_dir('[COLOR hotpink][B]20-30 Female[/B][/COLOR]', 'https://chaturbate.com/20to30-cams/female/?page=1',pn, channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]20-30 Male[/B][/COLOR]', 'https://chaturbate.com/20to30-cams/male/?page=1',pn, channelname, 55, icon, fanart)
        if female: util.add_dir('[COLOR hotpink][B]30-50 Female[/B][/COLOR]', 'https://chaturbate.com/30to50-cams/female/?page=1',pn,channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]30-50 Male[/B][/COLOR]', 'https://chaturbate.com/30to50-cams/male/?page=1',pn, channelname, 55, icon, fanart)
        if female: util.add_dir('[COLOR hotpink][B]50+ Female[/B][/COLOR]', 'https://chaturbate.com/mature-cams/female/?page=1',pn, channelname, 55, icon, fanart)
        if male: util.add_dir('[COLOR mediumorchid][B]50+ Male[/B][/COLOR]', 'https://chaturbate.com/mature-cams/male/?page=1', pn, channelname, 55, icon, fanart)

    elif 'ClearImages' in url:
        clean_database(showdialog=True)

def clean_database(showdialog=True):
    conn = sqlite3.connect(xbmc.translatePath("special://database/Textures13.db"))
    try:
        with conn:
            list = conn.execute("SELECT id, cachedurl FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            for row in list:
                conn.execute("DELETE FROM sizes WHERE idtexture LIKE '%s';" % row[0])
                try: os.remove(xbmc.translatePath("special://thumbnails/" + row[1]))
                except: pass
            conn.execute("DELETE FROM texture WHERE url LIKE '%%%s%%';" % ".highwebmedia.com")
            if showdialog:
                util.notifyClear('Finished','Chaturbate images Cleared.')
    except:
        pass


#CHATURBATE  #CHATURBATE #CHATURBATE #CHATURBATE
#CHATURBATE # GET Names and Icons. #############
def GetChannelName1(url,pn,mode,iconimage):
    totalusers = 0
    BROWSER_REFERER = 'https://chaturbate.com/'
    BROWSER_HEADER = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/54.0'
    req = urllib2.Request(url, headers={'User-Agent' : BROWSER_HEADER })
    page = urllib2.urlopen(req)
    if page and page.getcode() == 200:
        data = page.read()
        #datos = util.extractAll(data, '<li class="room_list_room"', '</li>')
        datos = util.extractAll(data, '<li class="room_list_room"', '<li class="cams">')
        for stuff in datos:
            totalusers = totalusers + 1
            channelname = util.extract(stuff, '<a href="/', '/">')
            backimage = util.extract(stuff, '<img src="', '"')
            ageof = util.extract(stuff, '<span class="age gender', '</span>')
            loca = util.extract(stuff, '<li class="location" style="display: none;">', '</li>')
            TheAge = ageof.replace('"', '').replace('f', '').replace('"', '').replace('>', '').replace('c', '').replace('s', '').replace('m', '').replace('&nbp;', '')
            util.add_dir2A('[COLOR violet]' + channelname + '[/COLOR][COLOR hotpink] ' + TheAge + '[/COLOR]', TheAge, loca, channelname, url, 5, backimage, backimage)
    else:
        util.notify('Error:','Error:')
    if totalusers >= 1:
        if pn == 0:
            pn = 1
        pn = int(pn) + 1
        url = url[:-1]
        url = url + str(pn)
        util.add_dir5A('[COLOR mediumvioletred]NEXT PAGE:' + str(pn) + '[/COLOR][COLOR mediumvioletred]>>[/COLOR]', url, pn, 55, icon, icon)

    setView('movies', 'thumb_view')

########## GET CHATURBATE VID URL FROM VID PAGE ### MAX ###.
def GetChaturbateVid1(VlistPage,channelname,url,mode,iconimage):
    BROWSER_REFERER = VlistPage
    BROWSER_HEADER = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/54.0'
    CAM_VID_PAGE = 'https://chaturbate.com/' + channelname
    req = urllib2.Request(CAM_VID_PAGE, headers={'User-Agent' : BROWSER_HEADER })
    page = urllib2.urlopen(req)
    if page and page.getcode() == 200:
        data = page.read()
        if '<source src=' in data:
            datos = util.extractAll(data, '<source src=', '></video></div>')
            for stuff in datos:
                vidURL = util.extract(stuff, '\'', '\' type=\'application/x-mpegURL')
                modeurl = vidURL
                playurl(modeurl,channelname,iconimage)
        else:
            line1 = channelname + ' is Offline. '
            line2 = 'Please Try Back Later.'
            line3 = CAM_VID_PAGE
            xbmcgui.Dialog().ok(addonname, line1, line2, line3)

###### Chaturbate ###### ASK #####
def GetChaturbateVid2(VlistPage,channelname,url,mode,iconimage):
    BROWSER_REFERER = VlistPage
    BROWSER_HEADER = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/54.0'
    CAM_VID_PAGE = 'https://chaturbate.com/' + channelname
    req11 = urllib2.Request(CAM_VID_PAGE, headers={'User-Agent' : BROWSER_HEADER })
    page11 = urllib2.urlopen(req11)
    if page11 and page11.getcode() == 200:
        data = page11.read()
        if '<source src=' in data:
            datos = util.extractAll(data, '<source src=', '></video></div>')
            for stuff in datos:
                vidURL = util.extract(stuff, '\'', '\' type=\'application/x-mpegURL')
                #print vidURL
                req2 = urllib2.Request(vidURL, headers={'User-Agent' : BROWSER_HEADER })
                page2 = urllib2.urlopen(req2)
                datos2 = page2.read()
                vidURL = vidURL.replace('playlist.m3u8', '')
                for line in datos2:
                    lines = datos2.split('\n')
                if len(lines) >= 4:
                    if lines[3] != "":
                        Stream01 = vidURL + lines[3]
                        VQ1 = "Quality One"
                        entries = [VQ1]
                if len(lines) >= 6:
                    if lines[5] != "":
                        Stream02 = vidURL + lines[5]
                        VQ2 = "Quality Two"
                        entries = [VQ1, VQ2]
                if len(lines) >= 8: # 480P Available
                    if lines[7] != "":
                        Stream03 = vidURL + lines[7]
                        VQ3 = "Quality Three"
                        entries = [VQ1, VQ2, VQ3]
                if len(lines) >= 10: # 576P Available
                    if lines[9] != "":
                        Stream04 = vidURL + lines[9]
                        VQ4 = "Quality Four"
                        entries = [VQ1, VQ2, VQ3, VQ4]
                if len(lines) >= 12:
                    if lines[11] != "":
                        Stream05 = vidURL + lines[11]
                        VQ5 = "Quality Five"
                        entries = [VQ1, VQ2, VQ3, VQ4, VQ5]
                if len(lines) >= 14:
                    if lines[13] != "":
                        Stream06 = vidURL + lines[13]
                        VQ6 = "Quality Six"
                        entries = [VQ1, VQ2, VQ3, VQ4, VQ5, VQ6]
                if len(lines) >= 16: # 1440P HD Available
                    if lines[15] != "":
                        Stream07 = vidURL + lines[15]
                        VQ7 = "Quality Seven"
                        entries = [VQ1, VQ2, VQ3, VQ4, VQ5, VQ6, VQ7]
                if len(lines) >= 18: # 2160P 4K Available
                    if lines[11] != "":
                        Stream08 = vidURL + lines[17]
                        VQ8 = "Quality Eight"
                        entries = [VQ1, VQ2, VQ3, VQ4, VQ5, VQ6, VQ7, VQ8]
                dialog = xbmcgui.Dialog()
                nr = dialog.select("Select Stream Quality:", entries)
                if nr>=0:
                    entry = entries[nr]
                    if str(entry) == "Quality One":
                        modeurl = Stream01
                    if str(entry) == "Quality Two":
                        modeurl = Stream02
                    if str(entry) == "Quality Three":
                        modeurl = Stream03
                    if str(entry) == "Quality Four":
                        modeurl = Stream04
                    if str(entry) == "Quality Five":
                        modeurl = Stream05
                    if str(entry) == "Quality Six":
                        modeurl = Stream06
                    if str(entry) == "Quality Seven":
                        modeurl = Stream07
                    if str(entry) == "Quality Eight":
                        modeurl = Stream08

                    playurl(modeurl,channelname,iconimage)
        else:
            line1 = channelname + ' is Offline. '
            line2 = 'Please Try Back Later.'
            line3 = CAM_VID_PAGE
            xbmcgui.Dialog().ok(addonname, line1, line2, line3)



def PlaybackSelect(VlistPage,url,channelname,mode,iconimage):
    # Select playback mode.
    if cb_playmode == 0:
        GetChaturbateVid1(VlistPage,channelname,url,mode,iconimage)
    if cb_playmode == 1:
        GetChaturbateVid2(VlistPage,channelname,url,mode,iconimage)
    return



def playurl(modeurl,channelname,iconimage):
    li = xbmcgui.ListItem(label=channelname, iconImage=iconimage, thumbnailImage=iconimage, path=modeurl)
    li.setInfo(type="Video", infoLabels={ "Title": '[COLOR pink]CAM:[/COLOR] [COLOR violet][B]' +  channelname + '[/B][/COLOR]', "plot": '[COLOR pink]You are watching:[/COLOR] ' + '[COLOR violet][B]' + channelname + '[/B][/COLOR] [CR] * Chat with ' + channelname + ' @ chaturbate.com! [CR]  [COLOR mediumaquamarine]* https://chaturbate.com/[/COLOR]' + channelname })
    xbmc.Player().play(item=modeurl, listitem=li)

def settings():
    xbmcaddon.Addon().openSettings()

def test():
    params = get_params()
    url = None
    name = None
    mode = None
    iconimage = None
    channelthumb = None
    channelname = 'None'
    VlistPage = 'None'
    pn = '1'
    try:
        pn = int(params["pn"])
    except:
        pass
    try:
        url = urllib.unquote_plus(params["url"])
    except:
        pass
    try:
        name = urllib.unquote_plus(params["name"])
    except:
        pass
    try:
        channelname = str(params["channelname"])
    except:
        pass
    try:
        VlistPage = str(params["VlistPage"])
    except:
        pass
    try:
        mode = int(params["mode"])
    except:
        pass
    try:
        iconimage = urllib.unquote_plus(params["iconimage"])
    except:
        pass
    try:
        channelthumb = urllib.unquote_plus(params["channelthumb"])
    except:
        pass

    if mode == None or url == None or len(url) < 1:
        main()
    elif mode == 2:
        start(url,pn,mode,channelname,iconimage)
    elif mode == 55:
        GetChannelName1(url,pn,mode,iconimage)
    elif mode == 5:
        PlaybackSelect(VlistPage,url,channelname,mode,iconimage)
    elif mode == 3:
        settings()
test()



xbmcplugin.endOfDirectory(int(sys.argv[1]))