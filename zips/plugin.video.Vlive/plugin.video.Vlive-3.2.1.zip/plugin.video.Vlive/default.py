import util, urllib2 , os , xbmcaddon , urllib , xbmcgui , xbmcplugin , random ,re ,random, ssl , sqlite3


addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
mysettings = xbmcaddon.Addon(id = 'plugin.video.Vlive')
getSetting = xbmcaddon.Addon().getSetting
setSetting = xbmcaddon.Addon().setSetting
enable_custom_params = mysettings.getSetting('enable_custom_params')
#enable_custom_srv_params = mysettings.getSetting('enable_custom_srv_params')
#enable_random_server = mysettings.getSetting('enable_random_server')
#enable_custom_server_number = mysettings.getSetting('enable_custom_server_number')
#enable_custom_rtmp_map = mysettings.getSetting('enable_custom_rtmp_map')


##################################################
BROWSER_REFERER = mysettings.getSetting('browser_referer')
BROWSER_HEADER = mysettings.getSetting('browser_header')
DOMAIN_TAG = mysettings.getSetting('domain_tag')

######## Set Default parameter values for updates.#######

if enable_custom_params == "false":
    BROWSER_REFERER = mysettings.setSetting(id='browser_referer', value='https://vaughnlive.tv/')
    BROWSER_HEADER = mysettings.setSetting(id='browser_header', value='Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/54.0')
    DOMAIN_TAG = mysettings.setSetting(id='domain_tag', value='live_')
    ##############################################
    BROWSER_REFERER = mysettings.getSetting('browser_referer')
    BROWSER_HEADER = mysettings.getSetting('browser_header')
    DOMAIN_TAG = mysettings.getSetting('domain_tag')


##################################################
thumbmode = int(mysettings.getSetting('thumb_type'))
playmode = int(mysettings.getSetting('play_mode'))
backmode = int(mysettings.getSetting('back_type'))
profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
nothumb = xbmc.translatePath(os.path.join(home, 'nophoto.jpg'))
logos = xbmc.translatePath(os.path.join(home, 'icon.png')) # subfolder for logos
homemenu = xbmc.translatePath(os.path.join(home, 'resources', 'playlists'))
MainSite = BROWSER_REFERER

enable_All = mysettings.getSetting('enable_All')
enable_Misc = mysettings.getSetting('enable_Misc')
enable_People = mysettings.getSetting('enable_enable_People')
enable_Nature = mysettings.getSetting('enable_Nature')
enable_Creative = mysettings.getSetting('enable_Creative')
enable_MusicCafe = mysettings.getSetting('enable_MusicCafe')
enable_NewsandTech = mysettings.getSetting('enable_NewsandTech')
enable_Lifestyles = mysettings.getSetting('enable_Lifestyles')
enable_Espanol = mysettings.getSetting('enable_Espanol')
enable_settings = mysettings.getSetting('enable_settings')
enable_favorites = mysettings.getSetting('enable_favorites')
enable_custom_view = mysettings.getSetting('enable_custom_view')
menu_view = mysettings.getSetting('menu_view')
thumb_view = mysettings.getSetting('thumb_view')
fav_view = mysettings.getSetting('fav_view')
back_view = mysettings.getSetting('back_view')
#xbmc.executebuiltin("Container.SetViewMode(50)")

ClearImages = 'ClearImages'
NextPage = 'NextPage'
PageOne = 'PageOne'

all = 'all'
misc = 'misc'
people = 'people'
nature = 'nature'
creative = 'creative'
musiccafe = 'musiccafe'
newsandtech = 'newsandtech'
lifestyles = 'lifestyles'
espanol = 'espanol'
GetVidInfo = 'GetVidInfo'
JerryRigged = 'JerryRigged'
Vselect = 'Vselect'


Categories = 'Categories'
Settings = 'Settings'
Favorites = 'Favorites'
favvch = 'favvch'
Addfavvch = 'Addfavvch'
#xbmcplugin.setContent(int(sys.argv[1]), 'movies')

profileDir = mysettings.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
favoritesdb = os.path.join(profileDir, 'favorites.db')

def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if mysettings.getSetting('enable_custom_view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % mysettings.getSetting(viewType) )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )


def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param


def main():
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    try:
        c.executescript("CREATE TABLE IF NOT EXISTS favorites (url, channelname, mode, iconimage);")
        c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
    except:
        pass
    conn.close()

    if getSetting("enable_All") == 'true':
        util.add_dir('All', all, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_Misc") == 'true':
        util.add_dir('Misc', misc, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_People") == 'true':
        util.add_dir('People', people, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_Nature") == 'true':
        util.add_dir('Nature', nature, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_Creative") == 'true':
        util.add_dir('Creative', creative, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_MusicCafe") == 'true':
        util.add_dir('Music Cafe', musiccafe, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_NewsandTech") == 'true':
        util.add_dir('News and Tech', newsandtech, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_Lifestyles") == 'true':
        util.add_dir('Lifestyles', lifestyles, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_Espanol") == 'true':
        util.add_dir('Espanol', espanol, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_favorites") == 'true':
        util.add_dir('[COLOR cadetblue][B]Favorites[/B][/COLOR]', Favorites, 0, 0, 0, 0, 2, icon, fanart)
    if getSetting("enable_settings") == 'true':
        util.add_dir3('[COLOR slategray]Settings[/COLOR]', Settings, 0, 0, None, 0, 3, icon, fanart)
    setView('movies', 'menu_view')



def start(url,fav,mode,ip,port,channelname,key,iconimage):
    if 'all' in url:
        ### VlistPage is the page the channels are listed on vaughnlive.
        VlistPage = MainSite + 'browse/all&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'misc' in url:
        VlistPage = MainSite + 'browse/misc&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'people' in url:
        VlistPage = MainSite + 'browse/people&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'nature' in url:
        VlistPage = MainSite + 'browse/nature&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'creative' in url:
        VlistPage = MainSite + 'browse/creative&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'musiccafe' in url:
        VlistPage = MainSite + 'browse/music_cafe&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'newsandtech' in url:
        VlistPage = MainSite + 'browse/news_tech&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'lifestyles' in url:
        VlistPage = MainSite + 'browse/lifestyles&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'espanol' in url:
        VlistPage = MainSite + 'browse/espanol&a=mvn'
        GetChannelName(VlistPage,url,mode,iconimage)
    elif 'GetVidInfo' in url:
        GetVID(ip,port,channelname,key,iconimage)
    elif 'JerryRigged' in url:
        PlayMode1(channelname,iconimage)
    elif 'Vselect' in url:
        PlaybackSelect(url,channelname,mode,iconimage)
    elif 'Favorites' in url:
        FavMain(url,channelname,mode,iconimage)


def FavMain(url,channelname,mode,iconimage):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    try:
        c.executescript("CREATE TABLE IF NOT EXISTS favorites (url, channelname, mode, iconimage);")
        c.executescript("CREATE TABLE IF NOT EXISTS keywords (keyword);")
    except:
        pass
    conn.close()
    List()
    util.add_dirFav(Favorites, '[COLOR slategray]Add New Channel[/COLOR]', 999, iconimage, iconimage)

def addFav(url, channelname, mode, iconimage):
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (url, channelname, mode, iconimage))
    conn.commit()
    conn.close()

def delFav(url, channelname, mode, iconimage):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE channelname = '%s'" % channelname)
    conn.commit()
    conn.close()

def List():
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    try:
        c.execute("SELECT * FROM favorites")
        for (url, channelname, mode, iconimage) in c.fetchall():
            iconimage = "https://cdn.vaughnsoft.com/vaughnsoft/vaughn/img_profiles/" + channelname + "_320.jpg"
            util.add_dirFav(Vselect, channelname, 4, iconimage, iconimage)
        connn.close()
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        xbmc.executebuiltin('Container.Refresh')
    except:
        conn.close()
        #util.notify('No Favorites','No Favorites found')
        return
    setView('movies', 'fav_view')



### Get the channel names and live images from the vl section page.
def GetChannelName(VlistPage,url,mode,iconimage):
    req = urllib2.Request(VlistPage, headers={'User-Agent' : BROWSER_HEADER,'Referer' : BROWSER_REFERER})
    page = urllib2.urlopen(req)
    if page and page.getcode() == 200:
        data = page.read()
        datos = util.extractAll(data, '<div class="browseThumb">', '</div>')
        for stuff in datos:
            channelname = util.extract(stuff, '<a href="/', '" target="_top">')
            channelx = '#vl-' + channelname
            if thumbmode == 0:
                #  LIVE CHANNEL IMAGE ...of what is playing.
                channelthumb = "http://" + util.extract(stuff, 'target="_top"><img src="//', '" class"browseThumb"')
                iconimage = channelthumb
            if thumbmode == 1:
                # DEFAULT PROFILE CHANNEL IMAGE
                channelthumb = "https://cdnvsft.r.worldssl.net/vaughnsoft/vaughn/img_profiles/" + channelname + "_320.jpg"
                iconimage = channelthumb
            if backmode == 0:
                # LIVE CHANNEL IMAGE ...of what is playing.
                backthumb = "http://" + util.extract(stuff, 'target="_top"><img src="//', '" class"browseThumb"')
                fanart = backthumb
            if backmode == 1:
                # DEFAULT PROFILE CHANNEL IMAGE
                backthumb = "https://cdnvsft.r.worldssl.net/vaughnsoft/vaughn/img_profiles/" + channelname + "_320.jpg"
                fanart = backthumb
            util.add_dir2A(Vselect, channelname, 4, channelthumb, backthumb)
    else:
        util.notify('Error:','Error:')
    setView('movies', 'thumb_view')

def Search1(url,fav,channelname,mode,iconimage):
    if channelname != '' or None:
        keyb = xbmc.Keyboard('', 'ADD Channel Name:')
        keyb.doModal()
        if keyb.isConfirmed() and len(keyb.getText().strip()) > 0 :
            search = keyb.getText()
            myParam = str(urllib.quote(search)).strip()
            channelname = str(myParam)
            return channelname
    else:
        channelname = 'Nothing Entered.'
        return channelname

def PlaybackSelect(url,channelname,mode,iconimage):
    # Select playback mode.
    if playmode == 0:
        PlayMode1(channelname,iconimage)
    if playmode == 1:
        #channelx = '#vl-' + channelname
        #PlayMode2(channelx,channelname,iconimage)
        PlayMode2(channelname,iconimage)
    return


#####################################################
MP4servers = ["mp4.vaughnsoft.net","mp4-remote.vaughnsoft.net"]
#MP4servers = ["mp4-remote.vaughnsoft.net"]
def api_url2():
    return random.choice(MP4servers)

def PlayMode1(channelname,iconimage):
    server = api_url2()
    VlistPage = BROWSER_REFERER + channelname
    req = urllib2.Request(VlistPage, headers={'User-Agent' : BROWSER_HEADER })
    page = urllib2.urlopen(req)
    if page and page.getcode() == 200:
        data = page.read()
        if 'mp4StreamUrl = "https://' in data:
            datos = util.extractAll(data, 'function serverShuffle', 'function handleVideoEventFlv')
            for stuff in datos:
                vidURL = util.extract(stuff, 'var mp4StreamUrl = "', '";')
                vidURL = vidURL.replace('{mp4Server}', server).replace('{streamName}', DOMAIN_TAG + channelname).replace('https}', 'http')
                modeurl = vidURL + '|Referer=' + VlistPage + '&User-Agent=' + BROWSER_HEADER
                playurl(modeurl,channelname,iconimage)
                #line1 = vidURL
                #xbmcgui.Dialog().ok(addonname, line1)
        else:
            line1 = "[COLOR=lightsalmon]Channel: [/COLOR][COLOR skyblue]" + channelname + "[/COLOR] [COLOR slategray]is[/COLOR] [COLOR indianred]OFFLINE.[/COLOR]"
            line2 = "This channel is currently unavailable."
            line3 = "Please check back later... "
            xbmcgui.Dialog().ok(addonname, line1, line2, line3)


#####################################################
def PlayMode2(channelname,iconimage):
    line1 = "[COLOR lightsalmon]RTMP[/COLOR] [COLOR skyblue]playback is no longer supported.[/COLOR]"
    line2 = "Change to html5 in the addon configuration."
    line3 = "Please change to html5. [COLOR slategray][RTMP][/COLOR] "
    xbmcgui.Dialog().ok(addonname, line1, line2, line3)

#####################################################

def playurl(modeurl,channelname,iconimage):
    li = xbmcgui.ListItem(label=channelname, iconImage=iconimage, thumbnailImage=iconimage, path=modeurl)
    li.setInfo(type="Video", infoLabels={ "Title": 'Channel: [COLOR skyblue][B]' +  channelname + '[/B][/COLOR]', "plot": '[COLOR powderblue]You are watching Channel:[/COLOR] ' + '[COLOR skyblue][B]' + channelname + '[/B][/COLOR] [CR] * Chat with others about ' + channelname + ' @ vaughnlive.tv! [CR]  [COLOR mediumaquamarine]* https://vaughnlive.tv/[/COLOR]' + channelname })
    xbmc.Player().play(item=modeurl, listitem=li)

def settings():
    xbmcaddon.Addon().openSettings()

def test():
    params = get_params()
    url = None
    fav = 'None'
    name = None
    mode = None
    iconimage = None
    channelthumb = None
    ip = '0'
    port = '0'
    key = '0'
    channelname = 'None'
    try:
        url = urllib.unquote_plus(params["url"])
    except:
        pass
    try:
        name = urllib.unquote_plus(params["name"])
    except:
        pass
    try:
        ip = str(params["ip"])
    except:
        pass
    try:
        port = str(params["port"])
    except:
        pass
    try:
        channelname = str(params["channelname"])
    except:
        pass
    try:
        fav = str(params["fav"])
    except:
        pass
    try:
        key = str(params["key"])
    except:
        pass
    try:
        mode = int(params["mode"])
    except:
        pass
    try:
        iconimage = urllib.unquote_plus(params["iconimage"])
    except:
        pass
    try:
        channelthumb = urllib.unquote_plus(params["channelthumb"])
    except:
        pass
    if mode == None or url == None or len(url) < 1:
        main()
    elif mode == 2:
        start(url,fav,mode,ip,port,channelname,key,iconimage)
    elif mode == 3:
        settings()
    elif mode == 4:
        PlaybackSelect(url,channelname,mode,iconimage)
    elif mode == 99: ### Remove from the favorites menu.
        delFav('Favorites', channelname, 2, iconimage)
        line1 = "[COLOR lightsalmon][B]Vlive Favorite: [/COLOR][COLOR indianred]REMOVED:[/B][/COLOR]"
        line2 = "[COLOR skyblue][B]" + channelname + "[/B][/COLOR]"
        xbmcgui.Dialog().ok(addonname, line1,line2)
        url = 'Favorites'
        fav = 'fav'
        xbmc.executebuiltin('Container.Refresh')
    elif mode == 999:  ### Add New channel in favorites menu.
        #if channelname == '':
        #    channelname = 'Enter Channel Name.'
        channelname = Search1(url,fav,'Enter Channel Name',mode,iconimage)
        if channelname == '' or channelname == None:
            channelname = 'Nothing Entered.'
        else:
            addFav('Favorites', channelname, 2, iconimage)
            line1 = "[COLOR lightsalmon][B]Vlive Favorite: [/COLOR][COLOR lightgreen]ADDED.[/B][/COLOR]"
            line2 = "[COLOR skyblue][B]" + channelname + "[/B][/COLOR]"
            xbmcgui.Dialog().ok(addonname, line1,line2)
            url = 'Favorites'
            fav = 'fav'
            xbmc.executebuiltin('Container.Refresh')
    elif mode == 1000: ### Add favorite from vlive channel menus.
        addFav('Favorites', channelname, 2, iconimage)
        line1 = "[COLOR lightsalmon][B]Vlive Favorite: [/COLOR][COLOR lightgreen]ADDED.[/B][/COLOR]"
        line2 = "[COLOR skyblue][B]" + channelname + "[/B][/COLOR]"
        xbmcgui.Dialog().ok(addonname, line1,line2)
        url = 'Favorites'
        fav = 'fav'
        #xbmc.executebuiltin('Container.Refresh')
test()



xbmcplugin.endOfDirectory(int(sys.argv[1]))